<?php 
include('head.php');
 ?>
<?php 
session_start();
$connect=mysqli_connect('localhost','root','','flightticketdb');
if(isset($_POST['btnlogin']))
	{
		$email=$_POST['txtemail'];
		$password= ($_POST['txtpassword']);
		$select="Select* from Staff where Email='$email' and Password='$password'";
		$run=mysqli_query($connect,$select);

		$count=mysqli_num_rows($run);
		if($count>0)
		{
			$staffdata=mysqli_fetch_array($run);
			$_SESSION['SID']=$staffdata['StaffID'];
			$_SESSION['Sname']=$staffdata['StaffName'];
			echo "<script> alert('login successful') </script>";
			echo "<script> window.location='Schedule.php'</script>";

		}
		else
		{
			echo "<script> alert('Your Password is Worng')</script>";
		}
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Staff</title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
	<form action="Stafflogin.php" method="POST">
	<div class="container">
	<h1>Staff Login</h1>
    <p>Welcome, Please fill in this form to login.</p>

	<label for="email"><b>Email</b></label>
	<input type="text" name="txtemail" placeholder="Enter Email" required="" id="email"><br>

	<label><b>Password</b></label>
	<input type="password" name="txtpassword" placeholder="Enter password" required="" ><br> 	
	<input type="submit" name="btnlogin" value="Login"  class="registerbtn">
</div>
	</form>
</body>
</html>
<?php 
 include('foot.php');
 ?>