<?php 
include('head.php');
 ?>
<?php 
session_start();
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');

if(isset($_POST['btnSearch']))
{
	$rdoSearchType=$_POST['rdoSearchType'];

	if($rdoSearchType==1)
	{
		$cboname=$_POST['cboname'];

		 $query="SELECT b.*, c.CustomerName
			FROM booking b,customer c 
			WHERE b.BookingID=c.BookingID
			AND c.CustomerID='$cboname'
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
	}
	elseif($rdoSearchType==2)
	{
		$booking=$_POST['cbobooking'];

		 $query="SELECT b.*, c.CustomerName
			FROM booking b,customer c 
			WHERE b.BookingID=c.BookingID
			AND b.BookingID='$booking'
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
	}

	else
	{
		$cbobookingdate=$_POST['cbobookingdate'];

		$query="SELECT b.*, c.CustomerName
			FROM booking b,customer c 
			WHERE b.BookingID=c.BookingID
			AND b.BookingDate='$cbobookingdate'
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
	}
}

elseif(isset($_POST['btnShowAll']))
{
	$query="SELECT b.*, c.CustomerName
			FROM booking b,customer c 
			WHERE b.BookingID=c.BookingID
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
}
else
{
	
	$query="SELECT b.*, c.CustomerName
			FROM booking b,customer c 
			WHERE b.BookingID=c.BookingID

			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
}

?>


<!DOCTYPE html>
<html>
<head>
<title>AdminSearch</title>
	<script type="text/javascript" src="DatePicker/datepicker.js"></script>
	<link rel="stylesheet" type="text/css" href="DatePicker/datepicker.css"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<style>
	
	.admin{
background-color: #302939;
color: #fff;
}


</style>
</head>
<body>
<form action="BookingSearch.php" method="POST">
	<div class="container">	
<fieldset>
<legend>Search Opiton:</legend>	
<table cellpadding="5px">
<tr>
	<td>
	<input type="radio" name="rdoSearchType" value="1" checked /> Search CustomerName <br>
	<select name="cboname">
		<option>Choose Customer Name</option>
		<?php 
		$Customer_Query="SELECT * FROM customer";
		$Customer_ret=mysqli_query($connect,$Customer_Query);
		$Customer_count=mysqli_num_rows($Customer_ret);

		for ($i=0; $i <$Customer_count ; $i++) { 
			$Customer_array=mysqli_fetch_array($Customer_ret);
			$CustomerID=$Customer_array['CustomerID'];
			$CustomerName=$Customer_array['CustomerName'];

			echo "<option value='$CustomerID'>$CustomerID - $CustomerName</option>";
		}

			?>
						
	</select>
	</td>

<td>
		<input type="radio" name="rdoSearchType" value="2"/>Search By BookingID <br>
		<select name="cbobooking">
			<option>Choose BookingID</option>
			<?php 
			$Booking_Query="SELECT * FROM booking";
			$Booking_ret=mysqli_query($connect,$Booking_Query);
			$booking_count=mysqli_num_rows($Booking_ret);

			for ($i=0; $i <$booking_count;$i++) { 
				$booking_array=mysqli_fetch_array($Booking_ret);
				$BookingID=$booking_array['BookingID'];
				

				echo "<option value='$BookingID'>$BookingID</option>";

			}
			 ?>

		</select>
		
	<td>
		<input type="radio" name="rdoSearchType" value="3" checked />Search By BookingDate
		<br>
		<select name="cbobookingdate">
			<option>Choose BookingDate</option>
			<?php 
			$BookingDate_Query="SELECT * FROM booking";
			$data_ret=mysqli_query($connect,$BookingDate_Query);
			$date_count=mysqli_num_rows($data_ret);

			for ($i=0; $i <$date_count ; $i++) { 
				$date_array=mysqli_fetch_array($data_ret);
				$BookingDate=$date_array['BookingDate'];

				echo "<option value='$BookingDate'>$BookingDate</option>";
			}
			 ?>
			
		</select>
	</td>

	<td>
	<input type="submit" name="btnSearch" value="Search"/ class="admin">
	<input type="submit" name="btnShowAll" value="Show All"/ class="admin">
	<input type="reset" name="Clear"/ class="admin">
	</td>

	</tr>
	</table>
	</fieldset>


<fieldset>
<legend>Search Result :</legend>
<?php 
if($count<1)
{
	echo "<p>No Booking Found.</p>";
}
else
{
?>

  <div style="overflow-x:auto;">
	<table>
	<tr>
		<th>BookingID</th>
		<th>BookingDate</th>
		<th>BookingTotalSeat</th>
		<th>CustomerName</th>
	</tr>
	<?php 
	for ($i=0; $i <$count ; $i++) { 
		$row=mysqli_fetch_array($result);
		$BookingID=$row['BookingID'];


		echo "<tr>";
		echo "<td>$BookingID</td>";
		echo "<td>" . $row['BookingDate'] . "</td>";
		echo "<td>" . $row['BookingTotalSeat'] . "</td>";
		echo "<td>" . $row['CustomerName'] . "</td>";
		echo "</tr>";
	}

	 ?>

	</table>	
<?php 
}
?>

</fieldset>
</div><br>
</form>
</body>
</html>
<?php 
include('foot.php');
 ?>