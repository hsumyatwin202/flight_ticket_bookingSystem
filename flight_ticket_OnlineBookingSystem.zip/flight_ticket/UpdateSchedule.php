<?php 
include('head.php');
 ?>
<?php 
session_start();
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');
if(isset($_GET['id']))
{
	$id=$_GET['id'];

	$select="select * from schedule where 
  ScheduleID='$id'";
	$run=mysqli_query($connect,$select);
	$row=mysqli_fetch_array($run);
	$depdate=$row['1'];
	$deptime=$row['2'];
	$arrivaltime=$row['3'];
	$retdate=$row['4'];
	$rettime=$row['5'];
	$id=$_GET['id'];
	$did=$row['7'];
}
if(isset($_POST['btnupdate'])){
  $Path=$_POST['rdopath'];

  if($Path=='OneWay'){
  $sid=$_POST['txtsid'];
  $depdate=$_POST['txtdep_date'];
  $deptime=$_POST['txtdep_time'];
  $arrivaltime=$_POST['txtarrival_time'];
  $retdate=null;
  $rettime=null;
  $id=$_POST['txtid'];
  $destination=$_POST['txtdestination'];

  }

  elseif($Path=='TwoWay'){
  $sid=$_POST['txtsid'];
  $depdate=$_POST['txtdepdate'];
  $deptime=$_POST['txtdeptime'];
  $arrivaltime=$_POST['txtarrivaltime'];
  $retdate=$_POST['txtreturndate'];
  $rettime=$_POST['txtreturntime'];
  $id=$_POST['txtid'];
  $destination=$_POST['txtdestination'];
  }

  $update="update schedule set
  ScheduleID='$sid',
  DepartureDate='$depdate',
  DepartureTime='$deptime',
  ArrivalTime='$arrivaltime',
  ReturnDate='$retdate',
  ReturnTime='$rettime',
  StaffID='$id',
  DestinationID='$destination'
  where ScheduleID='$sid'
  ";
  
  $run=mysqli_query($connect,$update);
    if ($run) {
      echo "<script>
      alert('Edited');
     window.location.assign('Schedule.php');
    </script>";
    }
    else{
      echo mysqli_error($connect);
    }

  }

?>

<!DOCTYPE html>
<html>
<head>
  <title>UpdateSchedule.php</title>
  <script type="text/javascript" src="jquery.js">
  </script>

  <script>
$(document).ready(
  function()
  {
    $(".TwoWay").hide();

    $("#rd1").click(
      function()
      {
        $(".TwoWay").hide();
        $(".OneWay").show();
      });

    $("#rd2").click(
      function()
      {
        $(".TwoWay").show();
        $(".OneWay").hide();
      });

  }); 
    

  </script>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
<form action="UpdateSchedule.php" method="POST">
   <div class="container">
	<label>
    <input type="radio" name='rdopath' value="OneWay" id="rd1" required="">OneWay
  </label>

  <label>
    <input type="radio" name='rdopath' value="TwoWay" id="rd2" required="">TwoWay
  </label><br>
  


  <div class="OneWay">
    <label><b>ScheduleID</b></label>
    <input type="text" name="txtsid" value="<?php echo $_GET['id']?>" readonly=""><br>
    <label><b>DepartureDate</b></label>
    <input type="Date" name="txtdep_date" value="<?php echo $depdate?>"><br>
    <label><b>DepartureTime</b></label>
    <input type="Time" name="txtdep_time" value="<?php echo $deptime?>"><br>
    <label><b>ArrivalTime</b></label>
    <input type="time" name="txtarrival_time" value="<?php echo $arrivaltime?>"><br>
    <label><b>StaffID</b></label>
    <input type="text" name="txtid" value="<?php echo $_SESSION['SID']?>" readonly=""><br>
    <label><b>DestinationID</b></label>
     <input type="text" name="txtdestination" value="<?php echo $did?>" readonly=""><br>
  </div>

  <div class="TwoWay">
    <label><b>ScheduleID</b></label>
    <input type="text" name="txtsid" value="<?php echo $_GET['id']?>" readonly=""><br>
    <label><b>DepartureDate</b></label>
    <input type="Date" name="txtdepdate" value="<?php echo $depdate?>"><br>
    <label><b>DepartureTime</b></label>
    <input type="Time" name="txtdeptime" value="<?php echo $deptime?>"><br>
    <label><b>ArrivalTime</b></label>
    <input type="time" name="txtarrivaltime" value="<?php echo $arrivaltime?>"><br>
    <label><b>ReturnDate</b></label>
    <input type="Date" name="txtreturndate" value="<?php echo $retdate?>"><br>
    <label><b>ReturnTime</b></label>
    <input type="Time" name="txtreturntime" value="<?php echo $rettime?>"><br>
   <label><b>StaffID</b></label>
    <input type="text" name="txtid" value="<?php echo $_SESSION['SID']?>" readonly=""><br>
    <label><b>DestinationID</b></label>
     <input type="text" name="txtdestination" value="<?php echo $did?>" readonly=""><br>
  </div>
 <input type="submit" name="btnupdate" value="Update" class="registerbtn">
 
 </div>
</form>
</body>
</html>
<?php 
include('foot.php');
 ?>