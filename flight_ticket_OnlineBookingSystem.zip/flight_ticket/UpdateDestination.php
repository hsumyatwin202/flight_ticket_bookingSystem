<?php 
include('head.php');
 ?>
<?php 
session_start();
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');
if(isset($_GET['id']))
{
	$id=$_GET['id'];

	$select="SELECT * FROM destination WHERE
	DestinationID='$id'";
	$run=mysqli_query($connect,$select);
	$row=mysqli_fetch_array($run);
	$destination=$row['1'];
	$price=$row['2'];
	$total=$row['3'];
	$fno=$row['4'];
	$cno=$row['5'];


}
if(isset($_POST['btnupdate']))
{
	$id=$_POST['txtdestinationid'];
	$destination=$_POST['txtdestination'];
	$price=$_POST['txtprice'];
	$total=$_POST['txttotalpassenger'];


	

	$update="update destination set
	Destination='$destination',
	Price='$price',
	TotalPassenger='$total'
	where DestinationID='$id'
	";

$run=mysqli_query($connect,$update);
		if ($run) {
			echo "<script>
			alert('Edited');
			window.location.assign('Destination.php');
		</script>";
		}
		else{
			echo mysqli_error($connect);
		}

}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>UpdateDestination.php</title>
 </head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
 <body>
 <form action="UpdateDestination.php" method="POST">
 	<div class="container">
 	<label><b>DestinationID</b></label>
 	<input type="text" name="txtdestinationid"  value="<?php echo $_GET['id']?>" readonly=""><br><br>
 	<label><b>Destination</b></label>
	<input type="text" name="txtdestination"  value="<?php echo $destination?>" ><br><br>
	<label><b>Price</b></label>
	<input type="text" name="txtprice"  value="<?php echo $price?>"><br><br>
	<label><b>TotalPassenger</b></label>
	<input type="text" name="txttotalpassenger"  value="<?php echo $total?>"><br><br>

	<label><b>FlightName</b></label>
	<input type="text" name="txtfname" value="<?php echo $fno?>" readonly=""><br><br>

	<label><b>ClassName</b></label>
	<input type="text" name="txtcname" value="<?php echo $cno?>" readonly=""><br>
<input type="submit" name="btnupdate" value="Update" class="registerbtn">
</div>

 	

 </form>
 </body>
 </html>
 <?php 
  include('foot.php');
 ?>