<?php 
include('Header.php');
 ?>
<?php 
session_start();
$connect=mysqli_connect('localhost','root','','flightticketdb');
	include('function.php');
//-------------------------------------------------------------//
if (isset($_SESSION['BookingID'])) 
	{
		$BookingID=$_SESSION['BookingID'];
		$query="SELECT b.*,s.*,d.* FROM Booking b, Schedule s,Destination d WHERE b.BookingID='$BookingID' AND s.ScheduleID=b.ScheduleID AND s.DestinationID=d.DestinationID";
		$result=mysqli_query($connect,$query);
		$arr=mysqli_fetch_array($result);
	}

//-------------------------------------------------------------//

if (isset($_POST['btnPayment']))
 {
	$PaymentID=AutoID('payment','PaymentID','P-',4);
	$PaymentDate=date('Y-m-d');
	$CardNo=$_POST['txtCardNo'];
	$BookingID=$_POST['txtBookingID'];
	$TotalAmount=$_POST['txtTotalAmount'];
	$PaymentType=$_POST['rdoPayment']; 
	echo $query="INSERT INTO Payment VALUES ('$PaymentID','$PaymentDate','$CardNo','$BookingID','$TotalAmount','$PaymentType')";
	$result=mysqli_query($connect,$query);

//-------------------------------------------------------------//

		if ($result)
			{
				echo "<script> window.alert ('Payment Successful') </script>";
				   echo "<script>window.location='CustomerDisplay.php'</script>";
			}
	}
 ?>

 <html>
 <head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
 	<title></title>
 </head>
 <script type="text/javascript">
 	
 	function show(){
 		document.getElementById('lblCardNo').style.display='block';
 		document.getElementById('txtCardNo').style.display='block';
 	}

//-------------------------------------------------------------//
 	
 	function hide(){
 		document.getElementById('lblCardNo').style.display='none';
 		document.getElementById('txtCardNo').style.display='none';
 	}

 </script>
 <body>

 	<form action="Payment.php" method="POST">
	<div class="container">

 			<label>Booking ID</label>
 			<input type="text"  name="txtBookingID" value="<?php echo $_SESSION['BookingID']; ?>" readonly>
 		
 		
 			<label><b>Ticket Price</b></label>
 			<input type="text" name="txtTicketPrice" value="<?php echo $arr['Price'] ?>" readonly>
 	
 			<label><b>No of Ticket</b></label>
 			<input type="text" name="txtNoofTicket" value="<?php echo $arr['BookingTotalSeat'] ?>" readonly>
 		
 			<label><b>Total Amount</b></label>
 			<input type="text" name="txtTotalAmount" value="<?php echo $arr['Price']*$arr['BookingTotalSeat'] ?>" readonly>
 		
 			<label><b>Payment Type</b></label>
 		
 				<input type="radio" name="rdoPayment" onclick="show()" value="MPU" checked>MPU
 				<input type="radio" name="rdoPayment" onclick="show()" value="Visa">Visa
 				<input type="radio" name="rdoPayment" onclick="hide()" value="Cash">Cash <br><br>
 			
 			<label id="lblCardNo">Card No</label>
 			<input type="text" name="txtCardNo" id="txtCardNo" required  placeholder="1111-2222-3333-4444"><br>
 		
 		
 			<input type="submit" name="btnPayment" value="Payment" class="registerbtn">	
 
</div>

 	</form>
 </body>
 </html>
 <?php 
include('Footer.php');
 ?>
