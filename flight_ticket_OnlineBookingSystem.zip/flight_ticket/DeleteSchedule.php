<?php 
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');
$id=$_GET['id'];

$delete="delete from schedule where ScheduleID='$id'";
$run=mysqli_query($connect,$delete);
	if ($run) {
		echo "<script>
			alert('Delete successfully');
			window.location.assign('Schedule.php');

		</script>";
	}
	else
	{
		echo mysqli_error($connect);
	}

 ?>