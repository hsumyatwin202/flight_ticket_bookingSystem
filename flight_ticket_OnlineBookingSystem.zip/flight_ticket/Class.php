<?php 
include('head.php');
 ?>
<?php 
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');

if(isset($_POST['btnsave']))
{
	$classno=AutoID('class','classno','CID_',6);
	$classtype=$_POST['txtclasstype'];

	$Insert="INSERT INTO `class`(`ClassNo`, `ClassType`) VALUES('$classno','$classtype')";

	$run=mysqli_query($connect,$Insert);

	if($run){
		echo "<script>alert('Saved')</script>";
	}
	else{
		echo mysqli_error($connect);
	}
}




 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Class.php</title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
<form action="Class.php" method="POST">
	 <div class="container">
	<label><b>ClassType</b></label>
	<input type="text" name="txtclasstype" required="" placeholder="Enter ClassType"><br>
	<input type="submit" name="btnsave" value="Save" class="registerbtn">
</div>
</form>
</body>
</html>
<?php 
include('foot.php');
 ?>
