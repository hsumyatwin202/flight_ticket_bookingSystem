<?php 
include('Header.php');
 ?>
<?php 
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');
	
	if ($_REQUEST['sid']) {
		$ScheduleID=$_REQUEST['sid'];
		$query="SELECT s.*,d.*,c.*,f.* FROM schedule s, destination d,class c,flight f
				WHERE s.ScheduleID='$ScheduleID' 
				AND d.DestinationID=s.DestinationID 
				AND c.ClassNo=d.ClassNo
				AND d.FlightNo=f.FlightNo";
		$result=mysqli_query($connect,$query);
		$arr=mysqli_fetch_array($result);
	}
	
 ?>
<html>
<head>
	<title></title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<style>
	
	.admin{
background-color: #302939;
color: #fff;
}
.no
{
	border: none;
	background-color: none;
}

</style>
<body>
	<form action="Booking.php" method="POST">
			<div class="container">
		<input type="hidden" name="txtScheduleID" value="<?php echo $ScheduleID; ?>">
		<input type="hidden" name="txtDestinationID" value="<?php echo $arr['DestinationID']; ?>">

  <div style="overflow-x:auto;">
	<table>
		<tr>
			<td>Destination Name</td>
			<td>Departure Date</td>
			<td>Departure Time</td>
			<td>Arrival Time</td>
			<td>Return Date</td>
			<td>Return Time</td>
			<td>Class Name</td>
			<td>Flight Name</td>
			<td>Price</td>
		</tr>
		<tr>
			<td><?php echo $arr['Destination']; ?></td>
			<td><?php echo $arr['DepartureDate']; ?></td>
			<td><?php echo $arr['DepartureTime']; ?></td>
			<td><?php echo $arr['ArrivalTime']; ?></td>
			<td><?php echo $arr['ReturnDate']; ?></td>
			<td><?php echo $arr['ReturnTime']; ?></td>
			<td><?php echo $arr['ClassType']; ?></td>
			<td><?php echo $arr['FlightName']; ?></td>
			<td><?php echo $arr['Price']; ?></td>
		</tr>
			</table>
</div><br>
			<h2>No Of Ticket</h2>
			<input  type="number" name="txtNoOfTicket"  min='1' max='5' placeholder="Please enter quantity">
			<input type="submit" name="btnBooking" value="Booking" class="admin"></td>
	</div><br><br>

	</form>
</body>
</html>
<?php 
include('Footer.php');
 ?>