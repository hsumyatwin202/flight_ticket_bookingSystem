<?php 
include('head.php');
 ?>
<?php 
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');

	if(isset($_GET['action']))
	{
		$id=$_GET['id'];

		 $delete="delete from staff where StaffID='$id'";

		$run=mysqli_query($connect,$delete);

		if ($run) {
			echo "<script>alert('Delete'); window.location='Staff.php'</script>";

		}
		else
		{
			echo mysqli_error($connect);
		}	
	}



	if(isset($_POST['btnsave']))
	{
		
		$staffname=$_POST['txtname'];
		$role=$_POST['rdorole'];
		$nrc=$_POST['txtnrc'];
		$phno=$_POST['txtphno'];
		$age=$_POST['txtage'];
		$gender=$_POST['rdogender'];
		$address=$_POST['txtaddress'];
		$email=$_POST['txtemail'];
		$password=$_POST['txtpassword'];
		$staffid=AutoID('staff','StaffID','SID_',6);
$Insert="INSERT INTO staff(StaffID, StaffName, Role, NRC, PhoneNumber, Age, Gender, Address, Email, Password) VALUES('$staffid','$staffname','$role','$nrc','$phno','$age','$gender','$address','$email','$password')";

	
		
		$run=mysqli_query($connect,$Insert);

		if ($run) {
			echo "<script>alert('Done')</script>";

		}
		else
		{
			echo mysqli_error($connect);
		}
	}

 ?> 
 

<!DOCTYPE html>
<html>
<head>
	<title>Staff.php</title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
	<form action="Staff.php" method="POST">
	<div class="container">
    <h1>Staff Register</h1>
    <p>Please fill in this form to create an account.</p>
	<label><b>Staff Name</b></label> 
	<input type="Text" name="txtname" placeholder="Enter Staff Name" required=""><br>

	<label><b>Role</b></label>
	<input type="radio" name="rdorole" value="Admin" required="" >Admin
	<input type="radio" name="rdorole" value="SaleStaff" required="">SaleStaff <br>

	<label><b>NRC</b></label>
	<input type="Text" name="txtnrc" required="" placeholder="Enter NRC"><br>
	
	<label><b>PhoneNumber</b></label>
	<input type="Text" name="txtphno" required="" placeholder="Enter PhoneNumber"><br>

	<label><b>Age</b></label>
	<input type="number" name="txtage" required="" placeholder="Enter Age"><br>

	<label><b>Gender</b></label>
	<input type="radio" name="rdogender" value="Male" required="">Male
	<input type="radio" name="rdogender" value="Female" required="">Female <br><br>

	<label ><b>Address</b></label>
	<textarea name="txtaddress" required="" placeholder="Enter Address"></textarea><br><br>

	<label for="email"><b>Email</b></label>
	<input type="email" name="txtemail" placeholder="Enter Email" id="email" required=""><br>

	<label for="psw"><b>Password</b></label>
	<input type="password" name="txtpassword" placeholder="Enter Password" required="" id="psw"><br>
	<input type="submit" name="btnsave" value="Save" class="registerbtn">
	
<div class="container signin">
    <p>Already have an account? <a href="Stafflogin.php">Sign in</a>.</p>
  </div><br>

  <div style="overflow-x:auto;">
	<table>
		<tr>
			<th>StaffID</th>
			<th>StaffName</th>
			<th>Role</th>
			<th>NRC</th>
			<th>PhoneNumber</th>
			<th>Age</th>
			<th>Gender</th>
			<th>Address</th>
			<th>Email</th>
			<th>Password</th>
			<th>Action</th>
		</tr>
		<?php 
		$select="Select * from staff";
		$run=mysqli_query($connect,$select);
		$count=mysqli_num_rows($run);

		for ($i=0; $i < $count ; $i++) 
		{ 
			$row=mysqli_fetch_array($run);
			$StaffID=$row[0];
			$Name=$row[1];
			$Role=$row[2];
			$NRC=$row[3];
			$PhNo=$row[4];
			$Age=$row[5];
			$Gender=$row[6];
			$Address=$row[7];
			$Email=$row[8];
			$Password=$row[9];

			echo "
			<tr>
					<td>$StaffID</td>
					<td>$Name</td>
					<td>$Role</td>
					<td>$NRC</td>
					<td>$PhNo</td>
					<td>$Age</td>
					<td>$Gender</td>
					<td>$Address</td>
					<td>$Email</td>
					<td>$Password</td>
					<td><a href='DeleteStaff.php?id=$StaffID'> Delete</a></td>
			</tr>
			";

		}


		 ?>


	</table>
	</div><br><br>
	</div>
</form>

</body>
</html>
<?php 
 include('foot.php');
 ?>