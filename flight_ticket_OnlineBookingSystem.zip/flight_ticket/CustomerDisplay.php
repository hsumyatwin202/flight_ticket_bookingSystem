<?php 
include('Header.php');
 ?>
<?php
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');



    $select="SELECT s.*, d.Destination, f.FlightName, c.ClassType
            FROM schedule s,destination d,class c,flight f
            WHERE f.FlightNo=d.FlightNo
            AND c.ClassNo=d.ClassNo
            AND d.DestinationID=s.DestinationID
            ORDER BY s.ScheduleID DESC";
    $ret=mysqli_query($connect,$select);
    $count=mysqli_num_rows($ret);

 ?>

 <html>
<head>
    <title></title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
<form action="CustomerDisplay.php" method="POST">
<div class="container">
    <h1>Flight Schedule</h1>
    <p>The Places that Available for Booking</p>   

<div style="overflow-x:auto;">
    <table >
        <tr>
            <th>DestinationName</th>
            <th>DepartureDate</th>
            <th>ReturnDate</th>
            <th>Class Type</th>
            <th>FlightName</th>
            <th>Action</th>
        </tr>

            
<?php
for($row=0; $row<$count; $row+=3)
{
 $innerselect="SELECT s.*, d.Destination, f.FlightName, c.ClassType
            FROM schedule s,destination d,class c,flight f
            WHERE f.FlightNo=d.FlightNo
            AND c.ClassNo=d.ClassNo
            AND d.DestinationID=s.DestinationID
            ORDER BY s.ScheduleID LIMIT $row,3";
$innerret= mysqli_query($connect,$innerselect);
$innercount= mysqli_num_rows($innerret);
    for($col=0; $col<$innercount; $col++)
     {
        $data= mysqli_fetch_array($innerret);
        $ScheduleID=$data['ScheduleID'];
        $Destination=$data['Destination'];
        $DepartureDate=$data['DepartureDate'];
        $ReturnDate=$data['ReturnDate'];
        $ClassType=$data['ClassType'];
        $FlightName=$data['FlightName'];

            echo "
            <tr>
                    <td>$Destination</td>
                    <td>$DepartureDate</td>
                    <td>$ReturnDate</td>
                    <td>$ClassType</td>
                    <td>$FlightName</td>
                    <td><a href='TicketDetail.php?sid=$ScheduleID'>Detail</a></td>
            </tr>
            ";
            

 ?>
         <?php 
             }
         }
         ?>
</table>

</div><br><br>
</div>
</form>
</body>
</html>

<?php 
include('Footer.php');
 ?>
