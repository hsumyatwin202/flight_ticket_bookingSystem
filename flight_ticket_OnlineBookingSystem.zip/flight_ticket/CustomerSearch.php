<?php 
include('Header.php');
 ?>
<?php 
session_start();
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');

if(isset($_POST['btnSearch']))
{
    $rdoSearchType=$_POST['rdoSearchType'];

    if($rdoSearchType==1)
    {
        $cbodestination=$_POST['cbodestination'];

          $query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
            FROM schedule s,destination d,class c,flight f
            WHERE f.FlightNo=d.FlightNo
            AND c.ClassNo=d.ClassNo
            AND d.DestinationID=s.DestinationID
            AND d.DestinationID='$cbodestination'
            ";
        $result=mysqli_query($connect,$query);
        $count=mysqli_num_rows($result);
    }
    elseif($rdoSearchType==2)
    {
        $depdate=$_POST['cboflight'];

        $query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
            FROM schedule s,destination d,class c,flight f
            WHERE f.FlightNo=d.FlightNo
            AND c.ClassNo=d.ClassNo
            AND d.DestinationID=s.DestinationID
            AND s.DepartureDate='$depdate'
            ";
        $result=mysqli_query($connect,$query);
        $count=mysqli_num_rows($result);
    }

    else
    {
        $cboscheduleid=$_POST['cboscheduleid'];

        $query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
            FROM schedule s,destination d,class c,flight f
            WHERE f.FlightNo=d.FlightNo
            AND c.ClassNo=d.ClassNo
            AND d.DestinationID=s.DestinationID
            AND s.ReturnDate='$cboscheduleid'
            ";
        $result=mysqli_query($connect,$query);
        $count=mysqli_num_rows($result);
    }
}

elseif(isset($_POST['btnShowAll']))
{
    $query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
            FROM schedule s,destination d,class c,flight f
            WHERE f.FlightNo=d.FlightNo
            AND c.ClassNo=d.ClassNo
            AND d.DestinationID=s.DestinationID
            ";
        $result=mysqli_query($connect,$query);
        $count=mysqli_num_rows($result);
}
else
{
    
    $query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
            FROM schedule s,destination d,class c,flight f
            WHERE f.FlightNo=d.FlightNo
            AND c.ClassNo=d.ClassNo
            AND d.DestinationID=s.DestinationID
            ";
        $result=mysqli_query($connect,$query);
        $count=mysqli_num_rows($result);
}

?>


<!DOCTYPE html>
<html>
<head>
<title>AdminSearch</title>
    <script type="text/javascript" src="DatePicker/datepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="DatePicker/datepicker.css"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<style>
    
    .admin{
background-color: #302939;
color: #fff;
}


</style>
</head>
<body>
<form action="CustomerSearch.php" method="POST">
    <div class="container"> 
<fieldset>
<legend>Search Opiton:</legend> 
<table cellpadding="5px">
<tr>
    <td>
    <input type="radio" name="rdoSearchType" value="1" checked /> Search Destination <br>
    <select name="cbodestination">
        <option>Choose Destination</option>
        <?php 
        $Destination_Query="SELECT * FROM destination";
        $Destination_ret=mysqli_query($connect,$Destination_Query);
        $Destinaiton_count=mysqli_num_rows($Destination_ret);

        for ($i=0; $i <$Destinaiton_count ; $i++) { 
            $Destination_arr=mysqli_fetch_array($Destination_ret);
            $DestinationID=$Destination_arr['DestinationID'];
            $Destination=$Destination_arr['Destination'];

            echo "<option value='$DestinationID'>$Destination</option>";
        }

            ?>
                        
    </select>
    </td>

<td>
        <input type="radio" name="rdoSearchType" value="2"/>Search By DepartureDate <br>
        <select name="cboflight">
            <option>Choose DepartureDate</option>
            <?php 
            $dep_query="SELECT * FROM schedule";
            $dep_ret=mysqli_query($connect,$dep_query);
            $dep_count=mysqli_num_rows($dep_ret);

            for ($i=0; $i <$dep_count;$i++) { 
                $dep_arr=mysqli_fetch_array($dep_ret);
                $DepartureDate=$dep_arr['DepartureDate'];

                echo "<option value='$DepartureDate'>$DepartureDate</option>";

            }
             ?>

        </select>
        
    <td>
        <input type="radio" name="rdoSearchType" value="3" checked />Search By ReturnDate
        <br>
        <select name="cboscheduleid">
            <option>Choose ReturnDate</option>
            <?php 
            $ret_query="SELECT * FROM schedule";
            $return_ret=mysqli_query($connect,$ret_query);
            $ret_count=mysqli_num_rows($return_ret);

            for ($i=0; $i <$ret_count ; $i++) { 
                $ret_arr=mysqli_fetch_array($return_ret);
                $ReturnDate=$ret_arr['ReturnDate'];

                echo "<option value='$ReturnDate'>$ReturnDate</option>";
            }
             ?>
            
        </select>
    </td>

    <td>
    <input type="submit" name="btnSearch" value="Search"/ class="admin">
    <input type="submit" name="btnShowAll" value="Show All"/ class="admin">
    <input type="reset" name="Clear"/ class="admin">
    </td>

    </tr>
    </table>
    </fieldset>


<fieldset>
<legend>Search Result :</legend>
<?php 
if($count<1)
{
    echo "<p>No Schedule Found.</p>";
}
else
{
?>

  <div style="overflow-x:auto;">
    <table>
    <tr>

        <th>DestinaitonName</th>
        <th>DepatureDate</th>
        <th>ReturnDate</th>
        <th>ClassType</th>
        <th>FlightName</th>
        <th>Action</th>
    </tr>
    <?php 
    for ($i=0; $i <$count ; $i++) { 
        $row=mysqli_fetch_array($result);
        $ScheduleID=$row['ScheduleID'];


        echo "<tr>";
       /* echo "<td>$ScheduleID</td>";*/
        echo "<td>" . $row['Destination'] . "</td>";
        echo "<td>" . $row['DepartureDate'] . "</td>";
        echo "<td>" . $row['ReturnDate'] . "</td>";
        echo "<td>" . $row['ClassType'] . "</td>";
        echo "<td>" . $row['FlightName'] . "</td>";
         echo"<td><a href='TicketDetail.php?sid=$ScheduleID'>Detail</a></td>";
        echo "</tr>";
    }   

     ?>

    </table>    
<?php 
}
?>

</fieldset>
</div><br>
</form>
</body>
</html>
<?php 
include('Footer.php');
 ?>