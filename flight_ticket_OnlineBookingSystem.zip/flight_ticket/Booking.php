<?php 
include('Header.php')
 ?>
<?php 
session_start();
$connect=mysqli_connect('localhost','root','','flightticketdb');
	include('function.php');

	if (isset($_POST['btnBooking'])) 
		{
			$_SESSION['Count']=$_POST['txtNoOfTicket'];
			$_SESSION['ScheduleID']=$_POST['txtScheduleID'];
			$_SESSION['DestinationID']=$_POST['txtDestinationID'];
		}

	if (isset($_POST['btnConfirm'])) 
		{
			$_SESSION['BookingID']=AutoID('booking','BookingID','B-',4);
			$BookingID=$_SESSION['BookingID'];
			$BookingDate=date('Y-m-d');
			$BookingTotalSeat=$_SESSION['Count'];
			$ScheduleID=$_SESSION['ScheduleID'];
			$query="INSERT INTO booking VALUES('$BookingID','$BookingDate','$BookingTotalSeat','$ScheduleID')";
			$result=mysqli_query($connect,$query);
			$DestinationID=$_SESSION['DestinationID'];
			echo $update="UPDATE Destination SET TotalPassenger=TotalPassenger-'$BookingTotalSeat' WHERE DestinationID='$DestinationID'";
			$result=mysqli_query($connect,$update);
				for ($i=1; $i <= $_SESSION['Count']; $i++) 
					{ 
						$CustomerID=AutoID('customer','CustomerID','CU-',4);
						$txtName="txtName".$i;
						$CustomerName=$_POST[$txtName];
						$txtNRC="txtNRC".$i;
						$CustomerNRC=$_POST[$txtNRC];
						$txtEmail="txtEmail".$i;
						$CustomerEmail=$_POST[$txtEmail];
						$txtPhone="txtPhone".$i;
						$CustomerPhone=$_POST[$txtPhone];
						$txtAddress="txtAddress".$i;
						$CustomerAddress=$_POST[$txtAddress];
						echo $query="INSERT INTO customer VALUES('$CustomerID','$CustomerName','$CustomerEmail','$CustomerAddress','$CustomerPhone','$CustomerNRC','$BookingID')";
						$result=mysqli_query($connect,$query);
					}
		if ($result)
			{
				echo "<script> window.alert ('Booking Successful') </script>";
				echo "<script> window.location='Payment.php' </script>";
			}
	}
 ?>
 
 <html>
 <head>
 	<title></title>
 </head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
 <body>
 	<form action="Booking.php" method="POST">
 		<div class="container">
 		<?php 
 		
 			for ($i=1; $i <= $_SESSION['Count']; $i++) { 
 		 ?>
 		 <fieldset>
 		 	<legend >Ticket <?php echo $i; ?></legend>

		 	
		 			<label><b>Customer Name</b></label>
		 			<input  type="text" name="txtName<?php echo $i;?>" required placeholder="Enter Your Name">
		 		

		 			<label><b>NRC (or) Passport No</b></label>
		 			<input  type="text" name="txtNRC<?php echo $i;?>" required placeholder="Enter Your NRC (or) Passport">

		 			<label><b>Email</b></label>
		 			<input type="Email" name="txtEmail<?php echo $i;?>" required placeholder="Enter Your Email"><br>

	
		 			<label><b>Phone Number</b></label>
		 			<input  type="text" name="txtPhone<?php echo $i;?>" required placeholder="Enter Your PhoneNumber">
		 		
		 			<label><b>Address</b></label>
		 			<textarea  name="txtAddress<?php echo $i;?>" required > </textarea>
		 	
 		</fieldset>
 		<?php 
 		}
 		 ?>


	<input type="submit" name="btnConfirm" value="Confirm" class="registerbtn"></td>

</div>
 	</form>
 </body>
 </html>

<?php 
include('Footer.php')
 ?>