<?php 
include('head.php');
 ?>
<?php 
session_start();
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');

if(isset($_POST['btnSearch']))
{
	$rdoSearchType=$_POST['rdoSearchType'];

	if($rdoSearchType==1)
	{
		$cbodestination=$_POST['cbodestination'];

		 $query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
			FROM schedule s,destination d,class c,flight f
			WHERE f.FlightNo=d.FlightNo
			AND c.ClassNo=d.ClassNo
			AND d.DestinationID=s.DestinationID
			AND d.DestinationID='$cbodestination'
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
	}
	elseif($rdoSearchType==2)
	{
		$flight=$_POST['cboflight'];

		$query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
			FROM schedule s,destination d,class c,flight f
			WHERE f.FlightNo=d.FlightNo
			AND c.ClassNo=d.ClassNo
			AND d.DestinationID=s.DestinationID
			AND f.FlightNo='$flight'
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
	}

	else
	{
		$cboscheduleid=$_POST['cboscheduleid'];

		$query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
			FROM schedule s,destination d,class c,flight f
			WHERE f.FlightNo=d.FlightNo
			AND c.ClassNo=d.ClassNo
			AND d.DestinationID=s.DestinationID
			AND s.ScheduleID='$cboscheduleid'
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
	}
}

elseif(isset($_POST['btnShowAll']))
{
	$query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
			FROM schedule s,destination d,class c,flight f
			WHERE f.FlightNo=d.FlightNo
			AND c.ClassNo=d.ClassNo
			AND d.DestinationID=s.DestinationID
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
}
else
{
	
	$query="SELECT s.*, d.Destination, f.FlightName, c.ClassType
			FROM schedule s,destination d,class c,flight f
			WHERE f.FlightNo=d.FlightNo
			AND c.ClassNo=d.ClassNo
			AND d.DestinationID=s.DestinationID
			";
		$result=mysqli_query($connect,$query);
		$count=mysqli_num_rows($result);
}

?>


<!DOCTYPE html>
<html>
<head>
<title>AdminSearch</title>
	<script type="text/javascript" src="DatePicker/datepicker.js"></script>
	<link rel="stylesheet" type="text/css" href="DatePicker/datepicker.css"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<style>
	
	.admin{
background-color: #302939;
color: #fff;
}


</style>
</head>
<body>
<form action="AdminSearch.php" method="POST">
	<div class="container">	
<fieldset>
<legend>Search Opiton:</legend>	
<table cellpadding="5px">
<tr>
	<td>
	<input type="radio" name="rdoSearchType" value="1" checked /> Search Destination <br>
	<select name="cbodestination">
		<option>Choose Destination</option>
		<?php 
		$Destination_Query="SELECT * FROM destination";
		$Destination_ret=mysqli_query($connect,$Destination_Query);
		$Destinaiton_count=mysqli_num_rows($Destination_ret);

		for ($i=0; $i <$Destinaiton_count ; $i++) { 
			$Destination_arr=mysqli_fetch_array($Destination_ret);
			$DestinationID=$Destination_arr['DestinationID'];
			$Destination=$Destination_arr['Destination'];

			echo "<option value='$DestinationID'>$DestinationID - $Destination</option>";
		}

			?>
						
	</select>
	</td>

<td>
		<input type="radio" name="rdoSearchType" value="2"/>Search By FlighNo <br>
		<select name="cboflight">
			<option>Choose FlightID</option>
			<?php 
			$flight_Query="SELECT * FROM flight";
			$flight_ret=mysqli_query($connect,$flight_Query);
			$flight_count=mysqli_num_rows($flight_ret);

			for ($i=0; $i <$flight_count;$i++) { 
				$flight_arr=mysqli_fetch_array($flight_ret);
				$flightID=$flight_arr['FlightNo'];
				$FlightName=$flight_arr['FlightName'];

				echo "<option value='$flightID'>$flightID - $FlightName</option>";

			}
			 ?>

		</select>
		
	<td>
		<input type="radio" name="rdoSearchType" value="3" checked />Search By ScheduleID
		<br>
		<select name="cboscheduleid">
			<option>Choose ScheduleID</option>
			<?php 
			$Schedule_Query="SELECT * FROM schedule";
			$Schedule_ret=mysqli_query($connect,$Schedule_Query);
			$Scheudle_count=mysqli_num_rows($Schedule_ret);

			for ($i=0; $i <$Scheudle_count ; $i++) { 
				$Schedule_arr=mysqli_fetch_array($Schedule_ret);
				$ScheduleID=$Schedule_arr['ScheduleID'];

				echo "<option value='$ScheduleID'>$ScheduleID</option>";
			}
			 ?>
			
		</select>
	</td>

	<td>
	<input type="submit" name="btnSearch" value="Search"/ class="admin">
	<input type="submit" name="btnShowAll" value="Show All"/ class="admin">
	<input type="reset" name="Clear"/ class="admin">
	</td>

	</tr>
	</table>
	</fieldset>


<fieldset>
<legend>Search Result :</legend>
<?php 
if($count<1)
{
	echo "<p>No Schedule Found.</p>";
}
else
{
?>

  <div style="overflow-x:auto;">
	<table>
	<tr>
		<th>ScheduleID</th>
		<th>DestinaitonName</th>
		<th>DepatureDate</th>
		<th>ArrivalDate</th>
		<th>DepatureTime</th>
		<th>ArrivalTime</th>
		<th>ClassType</th>
		<th>FlightName</th>
	</tr>
	<?php 
	for ($i=0; $i <$count ; $i++) { 
		$row=mysqli_fetch_array($result);
		$ScheduleID=$row['ScheduleID'];


		echo "<tr>";
		echo "<td>$ScheduleID</td>";
		echo "<td>" . $row['Destination'] . "</td>";
		echo "<td>" . $row['DepartureDate'] . "</td>";
		echo "<td>" . $row['ReturnDate'] . "</td>";
		echo "<td>" . $row['DepartureTime'] . "</td>";
		echo "<td>" . $row['ArrivalTime'] . "</td>";
		echo "<td>" . $row['ClassType'] . "</td>";
		echo "<td>" . $row['FlightName'] . "</td>";
		echo "</tr>";
	}

	 ?>

	</table>	
<?php 
}
?>

</fieldset>
</div><br>
</form>
</body>
</html>
<?php 
include('foot.php');
 ?>