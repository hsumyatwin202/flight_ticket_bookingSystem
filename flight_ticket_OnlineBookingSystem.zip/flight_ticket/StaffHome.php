<?php 
session_start();
$connect=mysqli_connect('localhost','root','','flightticketdb');
if (isset($_SESSION['Sname']))
{
	$Staff_Name=$_SESSION['Sname'];
}
else{
	echo "<script> window.alert('Please Login First')</script>";
		echo"<script> window.location='StaffLogin.php'</script>";
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>Welcome Admin <?php echo $Staff_Name; ?></p>
</body>
</html>
