-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2022 at 02:06 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flightticketdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `BookingID` varchar(8) NOT NULL,
  `BookingDate` varchar(50) NOT NULL,
  `BookingTotalSeat` int(11) NOT NULL,
  `ScheduleID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`BookingID`, `BookingDate`, `BookingTotalSeat`, `ScheduleID`) VALUES
('B-0008', '2020-06-03', 2, 'SCH_000001'),
('B-0009', '2020-06-03', 1, 'SCH_000003'),
('B-0010', '2020-06-03', 1, 'SCH_000003'),
('B-0011', '2022-02-27', 1, 'SCH_000001');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `ClassNo` varchar(20) NOT NULL,
  `ClassType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`ClassNo`, `ClassType`) VALUES
('CID_000001', 'Economy'),
('CID_000002', 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustomerID` varchar(10) NOT NULL,
  `CustomerName` varchar(30) NOT NULL,
  `NRC` varchar(50) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Phone` int(11) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `BookingID` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerID`, `CustomerName`, `NRC`, `Email`, `Phone`, `Address`, `BookingID`) VALUES
('CU-000001', 'hsu', 'hsu@gmail.com', 'No(222), Meepoint street, than', 98767872, '6/htawana(N) 155767', 'B-0008'),
('CU-0002', 'myat', 'myat@gmail.com', ' No(222), Meepoint street, tha', 98767872, '6/htawana(N) 155769', 'B-0008'),
('CU-0003', 'TinTinLatt', 'ttl@gmail.com', 'No(120), lathar street, yangon', 2147483647, '6/KaTha(N) 123456', 'B-0009'),
('CU-0004', 'afd', 'fasdf324@gmail.com', ' fasdf', 42332323, 'asdf', 'B-0011');

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `DestinationID` varchar(20) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Price` int(11) NOT NULL,
  `TotalPassenger` int(11) NOT NULL,
  `FlightNo` varchar(20) NOT NULL,
  `ClassNo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`DestinationID`, `Destination`, `Price`, `TotalPassenger`, `FlightNo`, `ClassNo`) VALUES
('DID_000003', 'Yangon-Myeik', 200, 27, 'FID_000003', 'CID_000002'),
('DID_000004', 'Yangon-Dawei', 85, 30, 'FID_000001', 'CID_000001'),
('DID_000005', 'Yangon-Mandalay', 113, 23, 'FID_000002', 'CID_000001');

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `FlightNo` varchar(20) NOT NULL,
  `FlightName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`FlightNo`, `FlightName`) VALUES
('FID_000001', 'MA223'),
('FID_000002', 'MA224'),
('FID_000003', 'Ma225');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PaymentID` varchar(20) NOT NULL,
  `PaymentDate` varchar(30) NOT NULL,
  `CardNo` int(11) NOT NULL,
  `BookingID` varchar(20) NOT NULL,
  `TotalAmount` int(11) NOT NULL,
  `PaymentType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `PaymentDate`, `CardNo`, `BookingID`, `TotalAmount`, `PaymentType`) VALUES
('P-000001', '2020-06-03', 2147483647, 'B-0008', 400, 'Visa'),
('P-0002', '2020-06-03', 2147483647, 'B-0009', 113, 'MPU'),
('P-0003', '2022-02-27', 2147483647, 'B-0011', 200, 'Visa');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `ScheduleID` varchar(20) NOT NULL,
  `DepartureDate` date NOT NULL,
  `DepartureTime` time NOT NULL,
  `ArrivalTime` time NOT NULL,
  `ReturnDate` date NOT NULL,
  `ReturnTime` time NOT NULL,
  `StaffID` varchar(20) NOT NULL,
  `DestinationID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`ScheduleID`, `DepartureDate`, `DepartureTime`, `ArrivalTime`, `ReturnDate`, `ReturnTime`, `StaffID`, `DestinationID`) VALUES
('SCH_000001', '2020-05-05', '03:30:00', '04:45:00', '0000-00-00', '00:00:00', 'SID_000001', 'DID_000003'),
('SCH_000002', '2020-05-06', '14:00:00', '14:45:00', '0000-00-00', '00:00:00', 'SID_000001', 'DID_000004'),
('SCH_000003', '2020-05-06', '08:20:00', '09:10:00', '2020-05-08', '10:15:00', 'SID_000001', 'DID_000005');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `StaffID` varchar(20) NOT NULL,
  `StaffName` varchar(20) NOT NULL,
  `Role` varchar(10) NOT NULL,
  `NRC` varchar(30) NOT NULL,
  `PhoneNumber` int(15) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `StaffName`, `Role`, `NRC`, `PhoneNumber`, `Age`, `Gender`, `Address`, `Email`, `Password`) VALUES
('SID_000001', 'Rupar', 'Admin', '7/thalana(N)00123456', 98740727, 29, 'Female', 'No(225),Sapal street, thanlyin, Yangon', 'Rupar@gmail.com', 'rupar'),
('SID_000002', 'Kyaw Zin', 'SaleStaff', '7/thalana(N)457369', 98765412, 23, 'Male', 'No(331), makyeekyeestreet, Sanchaung, Yangon', 'KyawZin@gmail.com', 'kyawzin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`BookingID`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`ClassNo`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `destination`
--
ALTER TABLE `destination`
  ADD PRIMARY KEY (`DestinationID`);

--
-- Indexes for table `flight`
--
ALTER TABLE `flight`
  ADD PRIMARY KEY (`FlightNo`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PaymentID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`ScheduleID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`StaffID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
