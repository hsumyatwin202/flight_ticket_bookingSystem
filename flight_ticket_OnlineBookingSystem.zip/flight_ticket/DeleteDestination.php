<?php 
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');
$id=$_GET['id'];

$delete="delete from destination where DestinationID='$id'";
$run=mysqli_query($connect,$delete);
	if ($run) {
		echo "<script>
			alert('Delete successfully');
			window.location.assign('Destination.php');

		</script>";
	}
	else
	{
		echo mysqli_error($connect);
	}

 ?>