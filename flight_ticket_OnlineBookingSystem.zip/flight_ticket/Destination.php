<?php 
include('head.php');
 ?>
<?php 
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');

if(isset($_GET['action']))
{
  $id=$_GET['id'];

  $delete="Delete from destination where DestinationID='$id'";

    $run=mysqli_query($connect,$delete);


    if ($run) {
      echo "<script>alert('Delete'); window.location='Destination.php'</script>";

    }
    else
    {
      echo mysqli_error($connect);
    } 

}

if(isset($_POST['btnsave']))
{
	$destinationid=AutoID('destination','destinationid','DID_',6);
	$destination=$_POST['txtdestination'];
	$price=$_POST['txtprice'];
	$totalpessenger=$_POST['txttotalpassenger'];
	$flightno=$_POST['cboflightname'];
	$classno=$_POST['cboclassname'];

$insert="INSERT INTO `destination`(`DestinationID`, `Destination`, `Price`, `TotalPassenger`, `FlightNo`, `ClassNo`) VALUES('$destinationid','$destination','$price','$totalpessenger','$flightno','$classno')";
$run=mysqli_query($connect,$insert);

if($run){
		echo "<script>alert('Saved')</script>";
	}
	else{
		echo mysqli_error($connect);
	}

}


 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
<form action="Destination.php" method="POST">
	<div class="container">
	<h1>Destination Entry</h1>
	<label><b>Destination</b></label>
	<input type="text" name="txtdestination" required="" placeholder="Enter Destination"><br><br>
	<label><b>Price</b></label>
	<input type="text" name="txtprice" required="" placeholder="Enter Price"><br><br>
	<label><b>TotalPassenger</b></label>
	<input type="text" name="txttotalpassenger" required="" placeholder="Enter Total Passenger"><br><br>
	
	<select name="cboflightname" required="">
		<option>Choose FlightName</option>
		<?php 
			$select="SELECT * FROM flight";
			$run=mysqli_query($connect,$select);
			$count=mysqli_num_rows($run);
			for ($i=0; $i < $count ; $i++) { 
				$row=mysqli_fetch_array($run);
				$flightname=$row[1];
				$flightno=$row[0];
				echo "<option value='$flightno'>$flightname</option>";
			}


		 ?>
	</select><br><br>

		<select name="cboclassname" required="">
		<option>Choose ClassName</option>
		<?php 
			$select="SELECT * FROM class";
			$run=mysqli_query($connect,$select);
			$count=mysqli_num_rows($run);
			for ($i=0; $i < $count ; $i++) { 
				$row=mysqli_fetch_array($run);
				$classname=$row[1];
				$classno=$row[0];
				echo "<option value='$classno'>$classname</option>";
			}


		 ?>
	</select><br>




	<input type="submit" name="btnsave" value="Save" class="registerbtn"> <br>

<div style="overflow-x:auto;">
<table>
  <tr>
    <th>DestinationID</th>
    <th>Destination</th>
    <th>Price</th>
    <th>TotalPassenger</th>
    <th>FlightNo</th>
    <th>ClassNo</th>
    <th>Action</th>
    <th>Action</th>

  </tr>
  <?php 
  $select="SELECT * FROM destination";
  $run=mysqli_query($connect,$select);
  $count=mysqli_num_rows($run);

  for ($i=0; $i <$count ; $i++) { 
    $row=mysqli_fetch_array($run);
    $DestinationID=$row[0];
    $destination=$row[1];
    $price=$row[2];
    $total=$row[3];
    $fno=$row[4];
    $cno=$row[5];
    echo "
    <tr> 
          <td>$DestinationID</td>
          <td>$destination</td>
          <td>$price</td>
          <td>$total</td>
          <td>$fno</td>
          <td>$cno</td>
          <td><a href='DeleteDestination.php?id=$DestinationID'>Delete </a></td>
          <td><a href='UpdateDestination.php?id=$DestinationID'>Update</a>
          </td>

    </tr>";
  }
  ?>
</table>
</div>
</div> <br><br>
</form>
</body>
</html>

<?php 
 include('foot.php');
 ?>