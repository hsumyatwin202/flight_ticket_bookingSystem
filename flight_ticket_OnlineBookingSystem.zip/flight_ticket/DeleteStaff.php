<?php 
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');
$id=$_GET['id'];

$delete="delete from staff where StaffID='$id'";
$run=mysqli_query($connect,$delete);
	if ($run) {
		echo "<script>
			alert('Delete successfully');
			window.location.assign('Staff.php');

		</script>";
	}
	else
	{
		echo mysqli_error($connect);
	}

 ?>