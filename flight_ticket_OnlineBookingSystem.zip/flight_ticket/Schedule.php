<?php 
include('head.php')
 ?>
<?php 
session_start();
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');

if(isset($_GET['action']))
{
  $ID=$_GET['id'];

  $delete="Delete from schedule where ScheduleID='$ID'";

    $run=mysqli_query($connect,$delete);


    if ($run) {
      echo "<script>alert('Delete'); window.location='Schedule.php'</script>";

    }
    else
    {
      echo mysqli_error($connect);
    } 

}
if(isset($_SESSION['SID']))

{
  $id=$_SESSION['SID'];

  $scheduleid=AutoID('schedule','ScheduleID','SCH_',6);

if(isset($_POST['btnsave'])){
  $Path=$_POST['rdopath'];

  if($Path=='OneWay'){
    $DepatureDate=date('Y-m-d', strtotime($_POST['txtdep_date']));
    $DepatureTime=$_POST['txtdep_time'];  
    $ArrivalTime=$_POST['txtarrival_time'];
    $ReturnDate=null;
    $ReturnTime=null; 
    $id=$_SESSION['SID'];
    $destinationid=$_POST['cbodesname'];


  }
  elseif ($Path=='TwoWay') {
   
    $DepatureDate=date('Y-m-d', strtotime($_POST['txtdepdate']));
    $DepatureTime=$_POST['txtdeptime'];
    $ArrivalTime=$_POST['txtarrivaltime'];
    $ReturnDate=date('Y-m-d', strtotime($_POST['txtreturndate']));
    $ReturnTime=$_POST['txtreturntime'];
    $id=$_SESSION['SID'];
    $destinationid=$_POST['cbodestination'];
    
  }

$insert="INSERT INTO schedule (ScheduleID, DepartureDate, DepartureTime, ArrivalTime, ReturnDate, ReturnTime, StaffID, DestinationID) 
                            VALUES ('$scheduleid','$DepatureDate','$DepatureTime','$ArrivalTime','$ReturnDate','$ReturnTime','$id','$destinationid')";


    $run=mysqli_query($connect,$insert);

    if ($run){
      echo "<script>window.alert('Saved')</script>";
    }
    else{
      echo mysqli_error($connect);
    }
}
}
 ?>


<!DOCTYPE html>
<html>
<head>
  <title>Schedule.php</title>
  <script type="text/javascript" src="jquery.js">
  </script>

  <script>
$(document).ready(
  function()
  {
    $(".TwoWay").hide();

    $("#rd1").click(
      function()
      {
        $(".TwoWay").hide();
        $(".OneWay").show();
      });

    $("#rd2").click(
      function()
      {
        $(".TwoWay").show();
        $(".OneWay").hide();
      });

  }); 
    

  </script>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
  <form action="Schedule.php" method="POST">
       <div class="container">
  <label>
    <input type="radio" name='rdopath' value="OneWay" id="rd1" required="">OneWay
  </label>

  <label>
    <input type="radio" name='rdopath' value="TwoWay" id="rd2" required="">TwoWay
  </label><br>
  


  <div class="OneWay">
    <label><b>DepartureDate</b></label>
    <input type="Date" name="txtdep_date"><br>
    <label><b>DepartureTime</b></label>
    <input type="Time" name="txtdep_time"><br>
    <label><b>ArrivalTime</b></label>
    <input type="time" name="txtarrival_time"><br>
    <label><b>StaffID</b></label>
    <input type="text" name="txtid" value="<?php echo $_SESSION['SID']?>" readonly=""><br>

    <select name="cbodesname">
    <option>Choose Destination</option>
    <?php 
      $select="SELECT * FROM destination";
      $run1=mysqli_query($connect,$select);
      $count=mysqli_num_rows($run1);
      for ($i=0; $i <= $count ; $i++) { 
        $row=mysqli_fetch_array($run1);
        $dname=$row[1];
        $did=$row[0];
        echo "<option value='$did'>$dname</option>";
      }


     ?>
  </select><br><br>
  </div>

  <div class="TwoWay">
    
    <label><b>DepartureDate</b></label>
    <input type="Date" name="txtdepdate"><br>
    <label><b>DepartureTime</b></label>
    <input type="Time" name="txtdeptime"><br>
   <label><b>ArrivalTime</b></label>
    <input type="time" name="txtarrivaltime"><br>
    <label><b>ReturnDate</b></label>
    <input type="Date" name="txtreturndate"><br>
    <label><b>ReturnTime</b></label>
    <input type="Time" name="txtreturntime"><br>
   <label><b>StaffID</b></label>
    <input type="text" name="txtid" value="<?php echo $_SESSION['SID']?>" readonly=""><br>


<select name="cbodestination">
    <option>Choose Destination</option>
    <?php 
      $select="SELECT * FROM destination";
      $run1=mysqli_query($connect,$select);
      $count=mysqli_num_rows($run1);
      for ($i=0; $i <= $count ; $i++) { 
        $row=mysqli_fetch_array($run1);
        $dname=$row[1];
        $did=$row[0];
        echo "<option value='$did'>$dname</option>";
      }


     ?>
  </select><br><br>
  </div>
 <input type="submit" name="btnsave" value="Save" class="registerbtn">
 
<div style="overflow-x:auto;">
<table border="1">
  <tr>
    <td>ScheduleID</td>
    <td>DepartureDate</td>
    <td>DepartureTime</td>
    <td>ArrivalTime</td>
    <td>ReturnDate</td>
    <td>ReturnTime</td>
    <td>StaffID</td>
    <td>DestinationID</td>
    <td>Action</td>
    <td>Action</td>
  </tr>
  <?php 
  $select="SELECT * FROM schedule";
  $run=mysqli_query($connect,$select);
  $count=mysqli_num_rows($run);

  for ($i=0; $i <$count ; $i++) { 
    $row=mysqli_fetch_array($run);
    $ScheduleID=$row[0];
    $depdate=$row[1];
    $deptime=$row[2];
    $arrivaltime=$row[3];
    $returndate=$row[4];
    $returntime=$row[5];
    $sid=$row[6];
    $did=$row[7];

    echo "
    <tr> 
          <td>$ScheduleID</td>
          <td>$depdate</td>
          <td>$deptime</td>
          <td>$arrivaltime</td>
          <td>$returndate</td>
          <td>$returntime</td>
          <td>$sid</td>
          <td>$did</td>
          <td><a href='DeleteSchedule.php?id=$ScheduleID'>
          Delete </a></td>
          <td><a href='UpdateSchedule.php?id=$ScheduleID'> Update </a></td>

    </tr>

    ";
  }
  ?>
</table>
</div><br><br>
</div>
  </form>

</body>
</html>
<?php 
include('foot.php')
 ?>
