<?php 
include('head.php');
 ?>
<?php 
include('function.php');
$connect=mysqli_connect('localhost','root','','flightticketdb');
if(isset($_POST['btnsave']))
	{
		$flightno=AutoID('flight','flightno','FID_',6);
		$flightname=$_POST['txtname'];
	

		 $Insert="INSERT INTO `flight`(`FlightNo`, `FlightName`) VALUES('$flightno','$flightname')";
		
		$run=mysqli_query($connect,$Insert);

		if ($run) {
					echo "<script> 
			alert('Done')</script>";

		}
		else
		{
			echo mysqli_error($connect);
		}
	}
 ?>


 <!DOCTYPE html>
<html>
<head>
	<title>Flight.php</title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<body>
	<form action="Flight.php" method='POST'>
		 <div class="container">
	<label><b>FlightName</b></label>
	<input type="text" name="txtname" required="" placeholder="Enter FlightName"><br>
	<input type="submit" name="btnsave" value="Save" class="registerbtn">
</div>
</form>
</body>
</html>
<?php 
include('foot.php');
 ?>